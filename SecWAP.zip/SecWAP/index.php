<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/telegram-dark-style@2.0.0/dist/style.min.css">
    <style>
        body {
            background-color: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            margin-top: 50px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
        }

        th {
            background-color: #61afe3;
            color: #1e1e1e;
        }

        input[type="text"] {
            padding: 8px;
            margin: 10px;
        }

        select {
            padding: 8px;
            margin: 10px;
        }

        .training-text {
            font-family: Calibri, 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 18px;
            margin-top: 20px;
        }
		        footer {
            text-align: center;
            margin-top: auto; /* Push the footer to the bottom */
            padding: 10px;
            background-color: #333; /* Optional background color */
            color: #fff; /* Optional text color */
        }
    </style>
</head>
<body>

<form action="" method="post">
    <label for="options">Select Option:</label>
    <select id="options" name="options">
        <option value="setup">Setup Configuration</option>
        <option value="vulnerable">Vulnerable Web Application Example( SQLi )</option>
        <option value="secure">Secure Web Application Example</option>
        <option value="addUser">Vulnerable Add User ( XSS Stored )</option>
		<option value="addUsersecure">Secure Add User</option>
    </select>
    <button type="submit">Execute</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedOption = $_POST["options"];
    
    switch ($selectedOption) {
        case "setup":
            include "mkdb.php";
            break;
        case "vulnerable":
            echo '<script>window.open("FindEmp.php", "_blank");</script>';
            break;
        case "secure":
            echo '<script>window.open("FindEmp-NoVuln.php", "_blank");</script>';
            break;
        case "addUser":
			echo '<script>window.open("addUser.php", "_blank");</script>';
            break;
		case "addUsersecure":
			echo '<script>window.open("addUser-secure.php", "_blank");</script>';
            break;
        default:
            // Handle default case if needed
            break;
    }
}

echo '<div class="training-text">This script is made for training purposes.</div>';
?>
<footer>
    <p>Powered By ENG. Khaled</p>
</footer>
</body>
</html>