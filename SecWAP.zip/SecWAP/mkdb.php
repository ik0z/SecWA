<?php
error_reporting(0);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hail_test";

// Establishing a connection
$conn = new mysqli($servername, $username, $password);

// Checking connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Creating database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    // Selecting the database
    $conn->select_db($dbname);

    // Creating employee table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS employee (
        empID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        Name VARCHAR(30) NOT NULL,
        Department VARCHAR(30) NOT NULL,
        Password VARCHAR(32) NOT NULL,
        Bio TEXT
    )";
    
    if ($conn->query($sql) === TRUE) {
        // Check if data already exists
        $result = $conn->query("SELECT * FROM employee LIMIT 1");
        if ($result->num_rows > 0) {
            echo "Already configured";
        } else {
            // Inserting data into the employee table with random MD5 passwords
            $sql = "INSERT INTO employee (empID, Name, Department, Password, Bio) VALUES
                (1, 'Khaled', 'Cybersecurity Management', '" . md5(generateRandomString()) . "', 'Cybersecurity Penetration Tester'),
                (2, 'Nizzar', 'Cybersecurity Management', '" . md5(generateRandomString()) . "', 'Cybersecurity GRC'),
                (3, 'PHPDev', 'Information Technology', '" . md5(generateRandomString()) . "', 'Developer PHP')";
            
            if ($conn->query($sql) === TRUE) {
                echo "Successfully configured!";
            } else {
                echo "Error inserting data: " . $conn->error;
            }
        }
    } else {
        echo "Error creating table: " . $conn->error;
    }
} else {
    echo "Error creating database: " . $conn->error;
}

// Closing the connection
$conn->close();

// Function to generate random string
function generateRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
?>