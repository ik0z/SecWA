<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/telegram-dark-style@2.0.0/dist/style.min.css">
    <style>
        body {
            background-color: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        form {
            margin-top: 20px;
        }

        label, input {
            margin: 10px;
        }

        input[type="submit"] {
            padding: 8px;
            margin: 10px;
            cursor: pointer;
        }

        .result {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hail_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if name and bio are not empty
    if (!empty($_POST["name"]) && !empty($_POST["bio"])) {
        $name = $conn->real_escape_string($_POST["name"]);
        $bio = $conn->real_escape_string($_POST["bio"]);

        // Insert user into the database
        $sql = "INSERT INTO employee (name, bio) VALUES ('$name', '$bio')";
        if ($conn->query($sql) === TRUE) {
            // Display success message
            echo '<div class="result">User added successfully.</div>';
        } else {
            // Display error message
            echo '<div class="result">Error: ' . $conn->error . '</div>';
        }
    } else {
        // Display error message if name or bio is empty
        echo '<div class="result">Error: Name and Bio cannot be empty.</div>';
    }
}

// Close connection
$conn->close();
?>

<form action="" method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="bio">Bio:</label>
    <input type="text" id="bio" name="bio" required>

    <input type="submit" value="Add User">
</form>

</body>
</html>
