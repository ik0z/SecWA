<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/telegram-dark-style@2.0.0/dist/style.min.css">
    <style>
        body {
            background-color: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            margin-top: 50px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
        }

        th {
            background-color: #61afe3;
            color: #1e1e1e;
        }

        input[type="text"] {
            padding: 8px;
            margin: 10px;
        }

        select {
            padding: 8px;
            margin: 10px;
        }
    </style>
</head>
<body class="tds">
    <form method="get">
        <label for="searchBy">Search By:</label>
        <select id="searchBy" name="searchBy">
            <option value="empID">Employee ID</option>
            <option value="Name">Name</option>
        </select>

        <label for="searchTerm">Search Term:</label>
        <input type="text" id="searchTerm" name="s" placeholder="Enter Search Term">
        <input type="submit" value="Search">
    </form>

    <?php
    if(isset($_GET['s'])) {
        $searchBy = $_GET['searchBy'];
        $searchTerm = $_GET['s'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hail_test";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM employee WHERE $searchBy='$searchTerm'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Field</th><th>Value</th></tr>";

            while($row = $result->fetch_assoc()) {
                echo "<tr><td>Employee ID</td><td>" . $row['empID'] . "</td></tr>";
                echo "<tr><td>Name</td><td>" . $row['Name'] . "</td></tr>";
                echo "<tr><td>Department</td><td>" . $row['Department'] . "</td></tr>";
                echo "<tr><td>Bio</td><td>" . $row['Bio'] . "</td></tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No matching records found</p>";
        }

        $conn->close();
    }
    ?>
</body>
</html>
